g++ -std=c++0x -g -W -o mymain limit.h general_cascade.cpp graph.cpp heap.cpp ir.cpp irie.cpp main.cpp
