g++ -std=c++0x -g -W -o mymain limit.h general_cascade.cpp graph.cpp staticgreedy.cpp staticgreedy_basic.cpp staticgreedy_directed_new.cpp main.cpp
#g++ -g -W -o mymain limit.h general_cascade.cpp graph.cpp staticgreedy.cpp staticgreedy_basic.cpp staticgreedy_directed_new.cpp main.cpp
