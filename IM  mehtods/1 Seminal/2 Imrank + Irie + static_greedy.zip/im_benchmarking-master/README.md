# im_benchmarking
Code for benhcmarking 12 state-of-the-art methods in the field of Influence Maximization
