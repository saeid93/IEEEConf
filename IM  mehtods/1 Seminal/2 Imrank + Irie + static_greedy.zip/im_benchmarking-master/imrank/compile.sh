g++ -g -o mymain limit.h general_cascade.cpp graph.cpp IMRank.cpp main.cpp
