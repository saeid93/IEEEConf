#!/bin/sh

g++ -std=c++14 -o main_test main_test.cpp
./main_test
